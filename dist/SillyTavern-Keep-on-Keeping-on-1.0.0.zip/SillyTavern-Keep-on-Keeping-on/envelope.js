// The call and its result exist only in the outbound request.
export const READ = 'kok_read_input';
export const EMIT = 'kok_emit_answer';
export const isGoogle = source => source === 'makersuite' || source === 'vertexai';
const sources = new Set(['openai', 'custom', 'openrouter', 'makersuite', 'vertexai']);
const chatTypes = new Set(['normal', 'regenerate', 'swipe', 'continue', 'impersonate']);
const delivery = '请按原任务要求作答，实际调用一次 ' + EMIT + '，把完整最终正文放入字符串参数 content，保留原文格式。不要用普通文本模拟调用。';

function tool(name, description, key) {
    return { type: 'function', function: { name, description, parameters: {
        type: 'object', properties: { [key]: { type: 'string' } }, required: [key],
    } } };
}

function uuid() {
    // getRandomValues also works on LAN HTTP, where randomUUID can be absent.
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}

function hasToolHistory(messages) {
    return messages.some(m => !m || ['tool', 'function'].includes(m.role) || m.tool_calls?.length ||
        m.function_call || m.tool_call_id);
}

export function prepare(body, { input, output }, newId = uuid) {
    const skip = reason => ({ reason });
    if (!input && !output) return skip('未开启封装');
    if (!body || !chatTypes.has(body.type)) return skip('非聊天生成');
    if (!sources.has(body.chat_completion_source)) return skip('当前连接类型未适配');
    if (!Array.isArray(body.messages) || !body.messages.length) return skip('没有聊天消息');
    if (body.tools?.length || body.tool_choice || body.functions?.length || body.function_call || hasToolHistory(body.messages)) {
        return skip('已有工具声明或工具历史');
    }
    if (body.json_schema || body.response_format || body.responseSchema || body.responseMimeType ||
        body.n > 1 || body.enable_web_search || body.request_images) return skip('结构化输出、多候选、搜索或生图请求');
    if (input && body.custom_prompt_post_processing && !['merge_tools', 'semi_tools', 'strict_tools'].includes(body.custom_prompt_post_processing)) {
        return skip('当前提示词后处理不保留工具历史');
    }
    const messages = [...body.messages];
    const tools = [];
    if (input) {
        const i = messages.findLastIndex(m => m.role === 'user');
        if (i < 0) return skip('没有 user 消息');
        const user = messages[i];
        const parts = typeof user.content === 'string' ? [{ type: 'text', text: user.content }] : user.content;
        if (!Array.isArray(parts) || parts.some(p => !p || (p.type === 'text' && typeof p.text !== 'string'))) {
            return skip('本轮输入格式不支持');
        }
        const raw = parts.filter(p => p.type === 'text').map(p => p.text).join('\n');
        if (!raw.trim() && !parts.some(p => p.type !== 'text')) return skip('本轮输入为空');
        const request_id = newId();
        const id = 'call_' + newId();
        const ref = '本轮用户原文见 ' + READ + ' 的工具结果（' + request_id + '），请按该用户输入和既有上下文回应。';
        let referenced = false;
        const replaced = parts.flatMap(p => {
            if (p.type !== 'text') return [p];
            if (referenced) return [];
            referenced = true;
            return [{ ...p, text: ref }];
        });
        messages[i] = { ...user, content: typeof user.content === 'string' ? ref : replaced };
        const call = { id, type: 'function', function: { name: READ, arguments: JSON.stringify({ request_id }) } };
        // Native Gemini uses ST's own signature adapter. Only Gemini behind a compatible endpoint
        // needs the documented Google extension field on the fabricated history entry.
        if (!isGoogle(body.chat_completion_source) && /gemini/i.test(body.model ?? '')) {
            call.extra_content = { google: { thought_signature: 'skip_thought_signature_validator' } };
        }
        messages.push({ role: 'assistant', content: null, tool_calls: [call] },
            { role: 'tool', tool_call_id: id, content: JSON.stringify({ request_id, input: raw }) });
        tools.push(tool(READ, '提供本轮用户输入；本地读取已经完成。', 'request_id'));
    }
    if (output) {
        tools.push(tool(EMIT, '提交用户可见的完整最终答复，不含内部思考。', 'content'));
        messages.push({ role: 'user', content: delivery });
    }
    // In non-streaming mode ST drops Gemini's finishReason, so consume its native
    // SSE transport and rebuild the ordinary ST response after validating STOP.
    const request = { ...body, messages, tools,
        tool_choice: output ? { type: 'function', function: { name: EMIT } } : 'none',
        stream: (output && isGoogle(body.chat_completion_source)) || body.stream,
    };
    return { request, output, clientStream: Boolean(body.stream), google: isGoogle(body.chat_completion_source) };
}

export class EnvelopeError extends Error {}
export function invalid(message) { throw new EnvelopeError(message); }
export function extractContent(name, args) {
    if (name !== EMIT) invalid('模型没有调用正文提交工具。');
    if (typeof args === 'string') {
        // Verify the one-string-property grammar as well as JSON validity. JSON.parse
        // alone would silently select the last of two duplicate content fields.
        let parsed;
        try { parsed = JSON.parse(args); } catch { invalid('工具参数不是完整 JSON。'); }
        if (args.replace(/"(?:[^"\\]|\\.)*"/gs, '""').replace(/\s/g, '') !== '{"":""}') invalid('工具参数必须只有一个字符串字段 content。');
        args = parsed;
    }
    if (!args || typeof args !== 'object' || Object.keys(args).length !== 1 ||
        !Object.hasOwn(args, 'content') || typeof args.content !== 'string' || !args.content.trim()) {
        invalid('正文工具缺少唯一的非空字符串 content。');
    }
    return args.content;
}
