import { EnvelopeError, prepare } from './envelope.js';
import { unwrapResponse } from './response.js';

const endpoint = '/api/backends/chat-completions/generate';

// This is the string URL + JSON BodyInit contract used by ST's sendOpenAIRequest.
// Stay transparent to Request objects, other extensions' network traffic and other origins.
export function wrapFetch(next, origin, options, report = () => {}) {
    return async function (resource, init) {
        const pass = () => next.call(this, resource, init);
        if (typeof resource !== 'string' && !(resource instanceof URL)) return pass();
        if (init?.method?.toUpperCase() !== 'POST' || typeof init.body !== 'string') return pass();
        const url = new URL(resource, origin);
        if (url.origin !== origin || url.pathname !== endpoint) return pass();
        const mode = options();
        if (!mode.input && !mode.output) return pass();
        let body;
        try { body = JSON.parse(init.body); } catch { return pass(); }
        const plan = prepare(body, mode);
        if (!plan.request) {
            if (body?.type !== 'quiet') report('已跳过：' + plan.reason);
            return pass();
        }
        report(plan.output ? '正在等待完整正文…' : '已封装本轮输入');
        try {
            const upstream = await next.call(this, resource, { ...init, body: JSON.stringify(plan.request) });
            const res = await unwrapResponse(upstream, plan);
            report(res.ok ? (plan.output ? '已提取正文' : '已封装输入，回复交由酒馆处理') : '上游返回错误');
            return res;
        } catch (e) {
            if (e instanceof EnvelopeError) {
                report(e.message);
                return new Response(JSON.stringify({ error: { message: '工具封装：' + e.message } }), {
                    status: 422, headers: { 'content-type': 'application/json' },
                });
            }
            report(init.signal?.aborted || e.name === 'AbortError' ? '已停止生成' : '请求失败');
            throw e;
        }
    };
}
